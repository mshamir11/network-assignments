server python3.8 tcp_server_sc_thread.py -p 0 &
client python3.8 tcp_client_new.py -p 0 -i "5" 
