server python3.8 tcp_server_sc_thread.py -p 0 &
H python3.8 tcp_client_new.py -p 0 -i "1" &
I python3.8 tcp_client_new.py -p 0 -i "2" &
J python3.8 tcp_client_new.py -p 0 -i "3" &
K python3.8 tcp_client_new.py -p 0 -i "4" 

















