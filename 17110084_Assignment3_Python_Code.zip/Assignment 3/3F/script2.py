i=0
while True :
    i=i+1
    print ('script 2:',i)